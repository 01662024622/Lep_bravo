<?php

namespace App\Repositories\HT40;

use App\Repositories\RepositoryInterface;

interface TopicRepository extends RepositoryInterface
{
    //
}