<?php

namespace App\Services\HT50;

use App\Services\ServiceInterface;

interface AccumulateService extends ServiceInterface
{
    //
}