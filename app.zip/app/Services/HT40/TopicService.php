<?php

namespace App\Services\HT40;

use App\Services\ServiceInterface;

interface TopicService extends ServiceInterface
{
    //
}