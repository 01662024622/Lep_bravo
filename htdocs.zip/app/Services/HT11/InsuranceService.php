<?php

namespace App\Services\HT11;

use App\Services\ServiceInterface;

interface InsuranceService extends ServiceInterface
{
    //
}