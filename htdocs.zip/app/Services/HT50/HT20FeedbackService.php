<?php

namespace App\Services\HT50;

use App\Services\ServiceInterface;

interface HT20FeedbackService extends ServiceInterface
{
    //
}