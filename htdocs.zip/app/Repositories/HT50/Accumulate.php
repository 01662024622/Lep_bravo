<?php

namespace App\Repositories\HT50;

use App\Repositories\RepositoryInterface;

interface Accumulate extends RepositoryInterface
{
    //
}