<?php

namespace App\Repositories\HT50;

use App\Repositories\RepositoryInterface;

interface HT20FeedbackRepository extends RepositoryInterface
{
    //
}