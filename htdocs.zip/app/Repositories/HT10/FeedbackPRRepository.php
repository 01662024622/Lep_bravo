<?php


namespace App\Repositories\Impl\HT00;


use App\Repositories\RepositoryInterface;

interface FeedbackPRRepository extends RepositoryInterface
{

}
