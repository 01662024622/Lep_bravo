<?php

namespace App\Repositories\HT11;

use App\Repositories\RepositoryInterface;

interface InsuranceRepository extends RepositoryInterface
{
    //
}