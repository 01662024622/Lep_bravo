<?php

namespace App\Repositories\HT20;

use App\Repositories\RepositoryInterface;

interface GroupRepository extends RepositoryInterface
{
    //
}